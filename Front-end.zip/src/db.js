const mongoose= require('mongoose');

mongoose.connect('mongodb://localhost:27017/Registeration',(err)=>{
    if(!err)
    console.log('connection successful...');
    else
    console.log('error occur...' + JSON.stringify(err, undefined, 2));
});
module.exports=mongoose;