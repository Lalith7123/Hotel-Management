import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Roomdetails } from 'src/pojomodel/Roomdetails';

@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {

  constructor(private http:HttpClient) { }

  getroomnow(){
    return this.http.get("http://localhost:8088/Admin/Getroom");
  }
  getstaffnow(){
    return this.http.get("http://localhost:8088/Admin/Getstaff");
  }
  getguestnow(){
    return this.http.get("http://localhost:8088/Admin/Getguest");
  }
  getbillnow(){
    return this.http.get("http://localhost:8088/Admin/Getbill");
  }
  getincomenow(){
    return this.http.get("http://localhost:8088/Admin/Getincome");
  }
  updateroomnow(room_no:Number,cost:Number){
    return this.http.put("http://localhost:8088/Admin/Updateroom/"+room_no+"/"+cost,{responseType:'text'});
  }
  getstaffbyaddressnow(address:String,occupation:String){
    return this.http.get("http://localhost:8088/Admin/Getstaffbyaddress/"+occupation+"/"+address);
  }
  getroombytypenow(roomtype:String){
    return this.http.get("http://localhost:8088/Admin/Getroombytype/"+roomtype);
  }
  getstaffbystatusnow(status:String){
    return this.http.get("http://localhost:8088/Admin/Getstaffbystatus/"+status);
  }
  getreservationnow(){
    return this.http.get("http://localhost:8088/Admin/Getreservation");
  }

  getroombyidnow(room_no:any){
    return this.http.get("http://localhost:8088/Admin/Getroombyno/"+room_no);
  }
}
