import { HttpClient } from '@angular/common/http';
import { Component, ComponentFactoryResolver, OnInit } from '@angular/core';
import { Billdetails } from 'src/pojomodel/Billdetails';
import { Guestdetails } from 'src/pojomodel/Guestdetails';
import { Reservationdetails } from 'src/pojomodel/Reservationdetails';
import { Roomdetails } from 'src/pojomodel/Roomdetails';
import { Staffdetails } from 'src/pojomodel/Staffdetails';
//import { any } from 'underscore';
import { AdminserviceService } from './adminservice.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  
  room: Roomdetails=new Roomdetails(0,"",0,0,"","","");
  staff: Staffdetails=new Staffdetails(0,"","","",0,"","");
  guest: Guestdetails=new Guestdetails(0,0,0,"",0,"","","",0,"","");
  reservation: Reservationdetails=new Reservationdetails(0,0,"",0,0,"","",0);
  bill: Billdetails=new Billdetails(0,0,0,0,0,0,0,0,"","","");
  getstaffif:any=null;
  getroomif:any=null;
  getguestif:any=null;
  getbillif:any=null;
  getroombytypeif:any=null;
  getstaffbystatusif:any=null;
  getstaffbyaddressif:any=null;
  getreservationif:any=null;
  getincomeif:any=null;
  updateroomif:any=null;
  openroomif:any=null;
  staffstatusif:any=null;
  staffaddressif:any=null;
  room_number:any=null;
  rooms:any;
  staffs:any;
  guests:any;
  bills:any;
  reservations:any;
  constructor(private service:AdminserviceService) { }

  ngOnInit(): void {
  }

  opengetroom(){
    this.getroomif=1;
    this.getstaffif=null;
    this.getguestif=null;
    this.getbillif=null;
    this.getreservationif=null;
    this.getincomeif=null;
    this.staffstatusif=null;
    this.staffaddressif=null;
    this.openroomif=null;
    this.updateroomif=null;
    this.getroom();
  }
  opengetstaff(){
  this.getstaffif=1;
  this.getroomif=null;
  this.getguestif=null;
  this.getbillif=null;
  this.getreservationif=null;
  this.getincomeif=null;
  this.staffstatusif=null;
  this.staffaddressif=null;
  this.openroomif=null;
  this.updateroomif=null;
  this.getstaff();
}  
opengetguest(){
  this.getguestif=1;
  this.getroomif=null;
  this.getstaffif=null;
  this.getbillif=null;
  this.getincomeif=null;
  this.staffstatusif=null;
  this.staffaddressif=null;
  this.getreservationif=null;
  this.openroomif=null;
  this.updateroomif=null;
  this.getguest();
}
opengetbill(){
  this.getbillif=1;
  this.getroomif=null;
  this.getstaffif=null;
  this.getguestif=null;
  this.getincomeif=null;
  this.staffstatusif=null;
  this.staffaddressif=null;
  this.getreservationif=null;
  this.openroomif=null;
  this.updateroomif=null;
  this.getbill();
}
opengetreservation(){
  this.getreservationif=1;
  this.getroomif=null;
  this.getstaffif=null;
  this.getguestif=null;
  this.getincomeif=null;
  this.staffstatusif=null;
  this.staffaddressif=null;
  this.getbillif=null;
  this.openroomif=null;
  this.updateroomif=null;
  this.getreservation();
}
opengetincome(){
  this.getincomeif=1;
  this.getreservationif=null;
  this.getroomif=null;
  this.getstaffif=null;
  this.getguestif=null;
  this.staffstatusif=null;
  this.staffaddressif=null;
  this.getbillif=null;
  this.openroomif=null;
  this.updateroomif=null;
  this.getincome();
  
}
openupdateroom(){
  this.updateroomif=1;
  this.getreservationif=null;
  this.getroomif=null;
  this.getstaffif=null;
  this.getguestif=null;
  this.getincomeif=null;
  this.staffstatusif=null;
  this.staffaddressif=null;
  this.getbillif=null;
  this.openroomif=null;
}
openroomtype(){
 
  this.getreservationif=null;
  this.getroomif=null;
  this.getstaffif=null;
  this.getguestif=null;
  this.getincomeif=null;
  this.staffstatusif=null;
  this.staffaddressif=null;
  this.getbillif=null;
  this.updateroomif=null;
  this.openroomif=1;
}
openstaffstatus(){
  
  this.staffstatusif=1;
  this.getstaffif=null;
  this.getreservationif=null;
  this.getroomif=null;
  this.staffaddressif=null;
  this.getguestif=null;
  this.getincomeif=null;
  this.getbillif=null;
  this.openroomif=null;
  this.updateroomif=null;
}
openstaffaddress(){
  this.staffaddressif=1;
  this.getreservationif=null;
  this.getroomif=null;
  this.getstaffif=null;
  this.getguestif=null;
  this.getincomeif=null;
  this.staffstatusif=null;
  this.getbillif=null;
  this.openroomif=null;
  this.updateroomif=null;
}
// Open finish

// Close starts

closestaffaddress(){
  this.staffaddressif=null;
}
closestaffstatus(){
  this.staffstatusif=null;
}
closeroomtype(){
  this.openroomif=null;
}
closegetincome(){
  this.getincomeif=null;
}
closegetroom(){
  this.getroomif=null;
}
closegetstaff(){
  this.getstaffif=null;
}
closegetguest(){
  this.getguestif=null;
}
closegetbill(){
  this.getbillif=null;
}
closegetreservation(){
  this.getreservationif=null;
}
closeupdateroom(){
  this.updateroomif=null;
}
closegetbytyperoom(){
  this.getroombytypeif=null;
}
closestaffbystatus(){
  this.getstaffbystatusif=null;
}
closestaffbyaddress(){
  this.getstaffbyaddressif=null;
}
// close finished
getroom(){
    this.service.getroomnow().subscribe((data)=>{
      console.log(data);
      this.rooms=data;
    })

  }

  getreservation(){
   
    this.service.getreservationnow().subscribe((data)=>{
      console.log(data);
      this.reservations=data;
    })
  }

  getstaff(){
   
    this.service.getstaffnow().subscribe((data)=>{
      console.log(data);
      this.staffs=data;
    })
  }
  getguest(){
    this.service.getguestnow().subscribe((data)=>{
      this.guests=data;
      console.log(data);
    })
  }
  getbill(){
    this.service.getbillnow().subscribe((data)=>{
      this.bills=data;
      console.log(data);
    })
  }
  Total:any;
  getincome(){
    this.service.getincomenow().subscribe((data)=>{
      this.Total=data;
      console.log(data);
    })
  }
  rate:any=null;

  updateroom(){
  
    
    this.service.updateroomnow(this.roomno,this.cost).subscribe((data)=>{
      this.rooms=data;
      alert("Updated Successfully")
    })
      
      this.closeupdateroom();
  }

  address:any=null;
  occupation:any=null;
  staffdetails:any;
  getstaffbyaddress(){
    this.service.getstaffbyaddressnow(this.address,this.occupation).subscribe((data)=>{
      this.staffdetails=data;
      console.log(this.staffdetails);
    })
    if(this.staffdetails==null){
      this.getstaffbyaddressif=null;
    }else{
      this.getstaffbyaddressif=1;
    }

  }
  

roomtype:any=null;

   roomtypes:any=null;
  getroombytype(){

    this.service.getroombytypenow(this.roomtype).subscribe((data)=>{
      this.roomtypes=data;
      console.log(this.roomtypes);
    })
    if(this.roomtypes==null){
      this.getroombytypeif=null;
    }else{
      this.getroombytypeif=1;
    }
    
  }
  salary_status:any=null;
  salstatus:any;
  getstaffbystatus(){
    this.service.getstaffbystatusnow(this.salary_status).subscribe((data)=>{
      this.salstatus=data;
      console.log(this.salstatus);
    })
    if(this.salstatus==null){
      this.getstaffbystatusif=null;
    }else{
      this.getstaffbystatusif=1;
    }
  }

roomno:any;
cost:any;
public getroombyid(roomid:any):Roomdetails{
    this.service.getroombyidnow(roomid).subscribe((data)=>{
      this.room1=data;
      console.log(this.room1.room_no);
    })
   
   return this.room1;
  }

   room1:Roomdetails=new Roomdetails(0,"",0,0,"","","");
  // rate:any=null;
  // updateroom(){
  //   this.getroombyid(this.roomno);
  //   this.room1.cost=this.cost;
  //   this.service.updateroomnow(this.roomno,this.cost).subscribe((data)=>{
  //     this.rooms=data;
  //     console.log(data);
  //     alert("Updated Successfully")
  //   })
    
  //     this.closeupdateroom();
  // }
  }

