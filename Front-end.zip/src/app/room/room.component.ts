import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {RoomService } from './room.service';


declare var window:any;
@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent implements OnInit {


  constructor(private service:RoomService,
    private param:ActivatedRoute) { }

foodData:any;
getMenuId:any;
menuData:any;
  ngOnInit(): void {
    this.foodData = this.service.foodDetails;

    this.getMenuId = this.param.snapshot.paramMap.get('id');
    console.log(this.getMenuId,'getmenu');
    if(this.getMenuId)
    {
      this.menuData =  this.service.foodDetails.filter((value)=>{
          return value.id == this.getMenuId;
        });
        console.log(this.menuData,'menudata>>');
        
    }
  }
  
 }





