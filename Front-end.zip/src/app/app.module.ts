import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpClientModule } from '@angular/common/http';

import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { ReceptionistComponent } from './receptionist/receptionist.component';
import { AdminComponent } from './admin/admin.component';
import { ManagerComponent } from './manager/manager.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { StaffComponent } from './staff/staff.component';
import { GuestComponent } from './guest/guest.component';
//import { ReservationComponent } from './reservation/reservation.component';

import { BillComponent } from './bill/bill.component';
//import { CheckComponent } from './check/check.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { MenuComponent } from './menu/menu.component';

@NgModule({
  declarations: [
    AppComponent,
    ReceptionistComponent,
    AdminComponent,
    ManagerComponent,
    StaffComponent,
    GuestComponent,
    //ReservationComponent,
    BillComponent,
    //CheckComponent,
    HomepageComponent,
    LoginComponent,
    UserComponent,
    MenuComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    
    BrowserAnimationsModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
