import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Billdetails } from 'src/pojomodel/Billdetails';
import { Guestdetails } from 'src/pojomodel/Guestdetails';
import { Reservationdetails } from 'src/pojomodel/Reservationdetails';

@Injectable({
  providedIn: 'root'
})
export class ReceptionistserviceService {

  constructor(private http:HttpClient) { }

  addguestnow(guest: Guestdetails){
    return this.http.post("http://localhost:8089/Receptionist/Addguest",guest,{responseType:'text'});
  }
  addreservationnow(reservation: Reservationdetails){
    return this.http.post("http://localhost:8089/Receptionist/Addreservation",reservation,{responseType:'text'});
  }
  addbillnow(bill: Billdetails){
    return this.http.post("http://localhost:8089/Receptionist/Addbill",bill,{responseType:'text'});
  }
  updateguestnow(guest:Guestdetails){
    return this.http.put("http://localhost:8089/Receptionist/Updateguest/"+guest.membercode,guest,{responseType:'text'});
  }
  deleteguestnow(guest:Guestdetails){
    return this.http.delete("http://localhost:8089/Receptionist/Deleteguest/"+guest.membercode,{responseType:'text'});
  }
  updatereservationnow(reservation:Reservationdetails){
    return this.http.put("http://localhost:8089/Receptionist/Updatereservation/"+reservation.id,reservation,{responseType:'text'});
  }
  deletereservationnow(reservation:Reservationdetails){
    return this.http.delete("http://localhost:8089/Receptionist/Deletereservation/"+reservation.id,{responseType:'text'});
  }
  getguestsnow(membercode:Guestdetails){
    return this.http.get("http://localhost:8089/Receptionist/Getguestbycode/"+membercode);
  }
  getreservationsnow(id:Reservationdetails){
    return this.http.get("http://localhost:8089/Receptionist/Getreservationbyid/"+id);
  }
  getbillsnow(){
    return this.http.get("http://localhost:8089/Receptionist/Getbill");
  }
  getguestbycode(code:Number){
    return this.http.get("http://localhost:8089/Receptionist/Getguestbycode/"+code);
  }
  checkoutguestnow(guest:Guestdetails){
    return this.http.put("http://localhost:8089/Receptionist/Checkout/"+guest.membercode,guest,{responseType:'text'});
  }
  checkroomnow(checkin:Number,checkout:Number,roomtype:String){
    return this.http.get("http://localhost:8089/Receptionist/Getrooms/"+checkin+"/"+checkout+"/"+roomtype);
  }

  getbillbycodenow(code:Number){ 
    return this.http.get("http://localhost:8089/Receptionist/Getbill/"+code); 
  }
}
