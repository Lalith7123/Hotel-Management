export class Orderfood{
membercode?:Number
dishname?:String
quantity?:Number

constructor(dishname?:String,membercode?:Number,quantity?:Number){
    this.dishname=dishname;
    this.membercode=membercode;
    this.quantity=quantity;
    
}

}
