import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Fooddetails } from 'src/pojomodel/Fooddetails';
//import { Orderfood } from '../menu/Orderfood';

@Injectable({
  providedIn: 'root'
})
export class StaffService {

  constructor(private http:HttpClient) { }

addfoodnow(Staffcode:Number,Food:Fooddetails){
  return this.http.post("http://localhost:8100/Foodstaff/Addfood/"+Staffcode,Food,{responseType:'text'}); 
}
getfoodnow(){
  return this.http.get("http://localhost:8100/Foodstaff/Getfood");
}

}
