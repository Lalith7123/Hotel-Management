
import { Component, OnInit } from '@angular/core';
import { Fooddetails } from 'src/pojomodel/Fooddetails';
import { Orderfood } from './Orderfood';
import { StaffService } from './staff.service';
declare var window:any;
@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent implements OnInit {
  options:any[]=[];
  order: Orderfood=new Orderfood("",0,0);
  addformModal:any;
  btntext:String="Add Dish";
  msgtext:String="add some dish";
  test=1;
  addfoodif:any=null;
  getfoodif:any=null;
  food: Fooddetails=new Fooddetails("",0,0);
  constructor(private service:StaffService) { }

  ngOnInit(): void {
    
  }

  addfoodform(){
    if(this.test==1){
    this.addfoodif=1;
    }else if(this.test==2){
      this.getfoodif=1;
      this.getfood();
    }
  }
 closeaddfood(){
  this.addfoodif=null;
  this.btntext="get dishes";
    this.msgtext="show available dishes";
    this.test=2;
 }
 closegetfood(){
  this.getfoodif=null;
  this.btntext="Add Dish";
  this.msgtext="add some dish";
  this.test=1;
 }
 addgetform(){
  this.getfoodif=1;
 }
staffcode:any=null;
  addfood(){
    if(this.food.dish_id==0 || this.food.dishname=="" || this.food.rate==0){
                   alert("Enter valid details");
    }else{
    this.service.addfoodnow(this.staffcode,this.food).subscribe((data)=>{
      alert(data);
      console.log(data);
      this.options.push(this.food.dishname);
    })
   
  }
  }

  foods:any;
  getfood()
{
  this.service.getfoodnow().subscribe((data)=>{
    this.foods=data;
 console.log(data);
  })
}




}

export const Teachers = [
  {name: 'Mr. Deep',subject:'Angular 6 in DotNet Techy YouTube Channel'},
  {name: 'Mr. Gautam' ,subject:'C#, WEB API in DotNet Techy YouTube Channel'},
  {name: 'Mr. DotNet Techy' ,subject:'High chart, chart js, prime ng, ag grid in DotNet Techy YouTube Channel '}
  ];