import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { BillComponent } from './bill/bill.component';
import { GuestComponent } from './guest/guest.component';
import { HomepageComponent } from './homepage/homepage.component';
//import { LoginComponent } from './login/login.component';
import { ManagerComponent } from './manager/manager.component';
//import { MenuComponent } from './menu/menu.component';
import { ReceptionistComponent } from './receptionist/receptionist.component';
//import { RegisterComponent } from './register/register.component';
import { RoomComponent } from './room/room.component';
import { StaffComponent } from './staff/staff.component';
import { UserComponent } from './user/user.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
const routes: Routes = [
  {path:"",redirectTo:"homepage",pathMatch:"full"},
  {path:"manager",component:ManagerComponent},
  //{path:"register",component:RegisterComponent}, 
  {path:"room",component:RoomComponent},
  {path:"staff",component:StaffComponent},
  {path:"login",component:LoginComponent},
  {path:"bill",component:BillComponent},
  {path:"guest",component:GuestComponent},
  {path:"admin",component:AdminComponent},
  {path:"receptionist",component:ReceptionistComponent},
  {path:"homepage",component:HomepageComponent},
  {path:"menu",component:MenuComponent},
  {path:"user",component:UserComponent},
  //{path:"menu",component:MenuComponent},

 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
