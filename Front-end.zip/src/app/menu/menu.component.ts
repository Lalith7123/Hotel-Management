import { Component, Input, OnInit } from '@angular/core';
import { Fooddetails } from 'src/pojomodel/Fooddetails';
import { Orderfood } from './Orderfood';
import { RoomService } from './room.service';
import {StaffComponent} from '../staff/staff.component';
declare var window:any;
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  tempfoods:Orderfood[]=[];
  constructor(private service:RoomService){}
    // private staff:StaffComponent) { }
    // @Input() options!: StaffComponent;
    //  c:any=this.options.options;
  foodData:any;
  food: Fooddetails=new Fooddetails("",0,0);
  formModalfood:any;
  membercode:any;
  order: Orderfood=new Orderfood("",0,0);
  ngOnInit(): void {
    this.foodData = this.service.foodDetails

    this.formModalfood=new window.bootstrap.Modal(
      document.getElementById("foodModal"))
  }

     openfoodModal(){
      this.formModalfood.show();
      this.getfood();
     }
     closefoodModal(){
      this.formModalfood.hide();
     }


     orderfood(){
          this.getfood();
      this.service.orderfoodnow(this.order).subscribe((data)=>{
        alert(data);      
        
              
      })
     }
     options:String[]=["one","two"];
foods:any;
tests:any;
     getfood(){
      this.service.getfoodnow().subscribe((data)=>{
        this.foods=data;
        console.log(this.foods);
      })
     
     }
     

}
