import { Component, OnInit } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';
import { Roomdetails } from 'src/pojomodel/Roomdetails';
import { Staffdetails } from 'src/pojomodel/Staffdetails';
import { ManagerserviceService } from './managerservice.service';
declare var window:any;
@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {
  rooms :any;
  staffs:any;
  formModalroom:any;
  formModalstaff:any;
  message:any;
  room: Roomdetails=new Roomdetails(0,"",0,0,"","","");
  roombyid:any;
  staff: Staffdetails=new Staffdetails(0,"","","",0,"","");
  
  detail:String="room details";
  formModelgetroom:any;
  formModelgetstaff:any;
  formModelroomforupdate:any;
  formModelroomfordelete:any;
  formModelstaffforupdate:any;
  formModelstafffordelete:any;
  constructor(private service:ManagerserviceService) { }

  ngOnInit(): void {
    this.formModalroom=new window.bootstrap.Modal(
      document.getElementById("roomModal")
    )
    this.formModalstaff=new window.bootstrap.Modal(
      document.getElementById("staffModal")
    )
    this.formModelgetroom=new window.bootstrap.Modal(
      document.getElementById("getroomModal")
    )
    this.formModelroomforupdate=new window.bootstrap.Modal(
      document.getElementById("roomModalforupdate")
    )
    this.formModelroomfordelete=new window.bootstrap.Modal(
      document.getElementById("roomModalfordelete")
    )
    this.formModelstaffforupdate=new window.bootstrap.Modal(
      document.getElementById("staffModalforupdate")
    )
    this.formModelstafffordelete=new window.bootstrap.Modal(
      document.getElementById("staffModalfordelete")
    )
  }
  openStafffordelete(){
    this.formModelstafffordelete.show();
  }
  closeStafffordelete(){
    this.formModelstafffordelete.hide();
  }
  openStaffforupdate(){
    this.formModelstaffforupdate.show();
  }
  closeStaffforupdate(){
    this.formModelstaffforupdate.hide();
  }
  openRoomforupdate(){
    this.formModelroomforupdate.show();
  }
  closeroomforupdate(){
    this.formModelroomforupdate.hide();
  }
  openRoomfordelete(){
    this.formModelroomfordelete.show();
  }
  closeroomfordelete(){
    this.formModelroomfordelete.hide();
  }
  openRoom(){
    this.formModalroom.show();
  }
  closeroom(){
    this.formModalroom.hide();
  }
  openGetroom(){
    this.formModelgetroom.show();
  }
  closeGetroom(){
    this.formModelgetroom.hide();
  }
  openStaff(){
    this.formModalstaff.show();
  }
  closeStaff(){
    this.formModalstaff.hide();
  }

  addroom(){
    this.service.addroomnow(this.room).subscribe(
      (data)=>{
       alert(data);
       console.log(data)

       this.message=data;})
   
    
  }

  addstaff(){
    console.log(this.staff);
    this.service.addstaffnow(this.staff).subscribe(
      (data)=>{
       alert(data);
       console.log(data)

       this.message=data;})
      }
  room_number:any;
  deletereturn:any;
  
  deleteroom(){

    this.service.deleteroomnow(this.room_number).subscribe((data)=>{
      this.deletereturn=data;
      console.log(data);
      console.log(JSON.stringify(this.deletereturn));
      alert(data);
    })
    this.closeroomfordelete();
  }


  ifclass0:any=null;
  num:Number=0;
  getAllroom(){
    if(this.num==0){
      this.ifclass0=1;
      this.service.getroomsnow().subscribe((data)=>
    {
      this.rooms=data;
      console.log(data);
    })
    this.num=1;
    }else{
      this.num=0;
      this.ifclass0=null;
    }
    
    
  }
  
  ifclass1:any=null;
  num1:Number=0;
  getallstaff(){
    if(this.num1==0){
      this.ifclass1=1;
      this.service.getstaffnow().subscribe((data)=>
    {
      this.staffs=data;
      console.log(data);
    })
    this.num1=1;
    }else{
      this.num1=0;
      this.ifclass1=null;
    }   
  }
  
  
   

  roomsforid:any;
  temproom: Roomdetails=new Roomdetails(0,"",0,0,"","","");
  getroombyid(){
  
    this.service.getroombyidnow(this.room_number).subscribe((data)=>
    {
      console.log(data);
      if(data==null){
        this.room=this.temproom;
      }
      else{
      this.room=data;
      }
      console.log(this.room_number);
      
    })
    
  }
   finalmsg2:any="";
  updateroom(){
    this.service.updateroomnow(this.room).subscribe((data)=>
    {
      this.finalmsg2=data;
      console.log(data);
      alert(data);
    })
  }
  staff_number:any;
  deletestaff(){
    this.service.deletestaffnow(this.staff_number).subscribe((data)=>{
      console.log(data);
      alert(data);
    })
    this.closeStafffordelete();
  }
 staffcode:any;
tempstaff: Staffdetails=new Staffdetails(0,"","","",0,"","");
  getstaffbyid(){
    this.service.getstaffbyidnow(this.staffcode).subscribe((data)=>{
      console.log(data);
    if(data==null){
          this.staff=this.tempstaff;
    }else{
      this.staff=data;
    }
    })

    
  }
  updatestaff(){
    this.service.updatestaffnow(this.staff).subscribe((data)=>{
      console.log(data);
      alert(data);
    })
     
  }
  getcredited(){
    this.service.getstaffstatusnow("credited").subscribe((data)=>{
      this.staffs=data;
      console.log(data);
    })
  }
  getnotcredited(){
    this.service.getstaffstatusnow("Not credited").subscribe((data)=>{
      this.staffs=data;
      console.log(data);
    })
  }


}
