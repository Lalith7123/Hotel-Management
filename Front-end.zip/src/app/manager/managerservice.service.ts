import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Roomdetails } from 'src/pojomodel/Roomdetails';
import { Staffdetails } from 'src/pojomodel/Staffdetails';

@Injectable({
  providedIn: 'root'
})
export class ManagerserviceService {

  constructor(private http:HttpClient) { }

  addroomnow(room:Roomdetails){
    return this.http.post("http://localhost:8086/Room/addrooms",room,{responseType:'text'});
  }
  addstaffnow(staff:Staffdetails){
    return this.http.post("http://localhost:8087/Staff/addstaff",staff,{responseType:'text'});
  }
  getroomsnow(){
    return this.http.get("http://localhost:8086/Room/getrooms");
  }
  getstaffnow(){
    return this.http.get("http://localhost:8087/Staff/getstaff");
  }
  getroombyidnow(id:Number){
    return this.http.get("http://localhost:8086/Room/getrooms/"+id);
  }
  getstaffbyidnow(id:Number){
    return this.http.get("http://localhost:8087/Staff/getstaffbyId/"+id)
  }
  updateroomnow(room:Roomdetails){
    return this.http.put("http://localhost:8086/Room/updateroom/"+room.room_no,room,{responseType:'text'});
  }
  deleteroomnow(room_number:Number){
    return this.http.delete("http://localhost:8086/Room/deleteroom/"+room_number,{responseType:'text'});
  }
  updatestaffnow(staff:Staffdetails){
    return this.http.put("http://localhost:8087/Staff/updatestaff/"+staff.staffcode,staff,{responseType:'text'});
  }
  deletestaffnow(staff_number:Number){
    return this.http.delete("http://localhost:8087/Staff/deletestaff/"+staff_number,{responseType:'text'});
  }
  getstaffstatusnow(status:String){
    return this.http.get("http://localhost:8087/Staff/getstaff/"+status);
  }
}
