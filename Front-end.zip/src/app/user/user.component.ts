import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import jsPDF from 'jspdf';
import { Billdetails } from 'src/pojomodel/Billdetails';
import { Reservationdetails } from 'src/pojomodel/Reservationdetails';
import { Roomdetails } from 'src/pojomodel/Roomdetails';
import { Guestdetails } from '../../pojomodel/Guestdetails';
import { UserserviceService } from './userservice.service';
import autoTable from 'jspdf-autotable';

declare var window:any;

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  @ViewChild('content', {static :false}) el!: ElementRef; 
 
  billModel:any;
  constructor(private service:UserserviceService) { }
  resif:any=null;
  ifclass0:any=null;
  message:any;
  addguestif:any=null;
  updateguestif:any=null;
  getbillif:any=null;
  addbillif:any=null;
  checkoutguestif:any=null;
  checkroomif:any=null;
  guest: Guestdetails=new Guestdetails(0,0,0,"",0,"","","",0,"","");
  reservation: Reservationdetails=new Reservationdetails(0,0,"",0,0,"","",0);
  bill: Billdetails=new Billdetails(0,0,0,0,0,0,0,0,"","","");
  room : Roomdetails =new Roomdetails();
  ngOnInit(): void {
    this.billModel=new window.bootstrap.Modal(
      document.getElementById("BillModel")
    )

  }

  openbillModel(){
    this.billModel.show();
  }
  closebillModel(){
    this.billModel.hide();
    this.Getbillbycode(this.bill.membercode);
  }


  openreservation(){
    this.resif=1;
    this.addbillif=null;
    this.addguestif=null;
    this.checkoutguestif=null;
    this.updateguestif=null;
    this.checkroomif=null;
  }
  openaddguest(){
    this.addguestif=1;
    this.resif=null;
    this.addbillif=null;
    this.checkoutguestif=null;
    this.updateguestif=null;
    this.checkroomif=null;
  }
  openupdateguest(){
    this.updateguestif=1;
    this.resif=null;
    this.addbillif=null;
    this.addguestif=null;
    this.checkoutguestif=null;
    this.checkroomif=null;
  }
  openaddbill(){
    this.addbillif=1;
    this.resif=null;
    this.addguestif=null;
    this.checkoutguestif=null;
    this.updateguestif=null;
    this.checkroomif=null;
  }
  opencheckout(){
    this.checkoutguestif=1;
    this.resif=null;
    this.addbillif=null;
    this.addguestif=null;
    this.updateguestif=null;
    this.checkroomif=null;
  }
  opencheckroom(){
    this.checkroomif=1;
    this.resif=null;
    this.addbillif=null;
    this.addguestif=null;
    this.checkoutguestif=null;
    this.updateguestif=null;
  }
closecheckroomif(){
  this.checkroomif=null;
  this.ifclass0=null;
}


  n:number=1;
  addreservation(){ 
    console.log(this.reservation); 
    this.reservation.check_in=this.testfunction(this.reservation.check_in); 
    this.reservation.check_out=this.testfunction(this.reservation.check_out); 
    this.service.addreservationnow(this.reservation).subscribe((data)=>{ 
     alert(data);
      console.log(data); 
      this.message=data; 
    }) 
   
  }

  addguest(){
    this.service.addguestnow(this.guest).subscribe(
      (data)=>{
       alert(data);
       console.log(data)
  
       this.message=data;})
  }
  
    updateguest(){

      this.service.updateguestnow(this.guest).subscribe((data)=>{
       alert("Updated");
        console.log(data);
        this.message=data;
      })
    }

    tempguest: Guestdetails=new Guestdetails(0,0,0,"",0,"","","",0,"","");
    guestcode:any=null;
    getguestbycode(){
      this.service.getguestbycode(this.guestcode).subscribe((data)=>{
        
        console.log(data);
        if(data==null){
          this.guest=this.tempguest;
    }else{
      this.guest=data;
    }
      })
      
    }

    memcode:any;
    bills:any;
    demobill: Billdetails=new Billdetails(0,0,0,0,0,0,0,0,"","","");
    Getbillbycode(code:any){
     
      this.service.getbillbycodenow(code).subscribe((data)=>{ 
       
        this.bills=data;
        console.log(this.bills); 
        this.makepdf();
      }) 
      
    }
    addbill(){
      let message:any;
      this.service.addbillnow(this.bill).subscribe((data)=>{
        message=data;
        alert(message);
        if(data =="Your Payment is successfull"){
          this.openbillModel();
         
        }
      })
     
      
    }
    checkoutguest(){
      this.service.checkoutguestnow(this.guest).subscribe((data)=>{
        this.message=data;
        console.log(data);
        alert(data);
      })
    
  }
  checkin:any=null;
  checkout:any=null;
  roomtype:String="";
rooms:any;
  checkroom(){
    console.log(this.checkin);
    this.checkin=this.testfunction1(this.checkin);
    this.checkout=this.testfunction1(this.checkout);
    console.log(this.checkin);
    this.service.checkroomnow(this.checkin,this.checkout,this.roomtype).subscribe((data)=>{
      this.rooms=data;
      console.log(data);
    })
    this.ifclass0=1;
    this.checkroomif=1;
  }


    // let demopdf=new jsPDF('p','pt','a4'); 
  //  demopdf.html(this.el.nativeElement,{ 
  //     callback:(demopdf)=>{ 
  //       demopdf.save("bill.pdf"); 
  //     } 
  //       }) 
       
  makepdf(){ 
    // let doc=new jsPDF('p','pt','a4'); 
  //  demopdf.html(this.el.nativeElement,{ 
  //     callback:(demopdf)=>{ 
  //       demopdf.save("bill.pdf"); 
  //     } 
  //       }) 

  const doc = new jsPDF() 
 

autoTable(doc, { html: '#my-table' }) 
 

  doc.text("Bill Credentials",85, 10);
  doc.text("Manager's Signature",150, 160);


autoTable(doc, { 
  
  head: [['s no', 'Bill', 'Details']], 
  body: [ 
    ['1', 'Bill.no', this.bills.billno], 
    ['2', 'Roomno', this.bills.room_no], 
    ['3', 'Reservation_id',this.bills.id], 
    ['4', 'Membercode', this.bills.membercode], 
    ['5', 'Total', this.bills.total], 
    ['6', 'Tax', this.bills.tax], 
    ['7', 'GST', this.bills.gst], 
    ['8', 'Total Amount', this.bills.totalAmount], 
    ['9', 'Paytime', this.bills.paytime],  
    ['10', 'card Details', this.bills.card_details], 
    ['11', 'Payment Status', this.bills.payment_status], 
    
  ], 
}) 
 
doc.save('table.pdf')   



  // demopdf.text("Billid: "+this.bills.billno,10,30);
  // demopdf.text("Roomno: "+this.bills.room_no,10,50);
  // demopdf.text("Reservation_id: "+this.bills.id,10,70);
  // demopdf.text("Membercode: "+this.bills.membercode,10,90);
  // demopdf.text("Total: "+this.bills.total,10,110);
  // demopdf.text("Tax: "+this.bills.tax,10,130);
  // demopdf.text("GST: "+this.bills.gst,10,150);
  // demopdf.text("Total Amount: "+this.bills.totalAmount,10,170);
  // demopdf.text("Paytime: "+this.bills.paytime,10,190);
  // demopdf.text("Card Details: "+this.bills.card_details,10,210);
  // demopdf.text("Payment Status: "+this.bills.payment_status,10,230);
    

        // demopdf.save("bill.pdf"); 
  }


  testfunction(date:any):String{ 
    let str:String=date; 
    let strarr:String[]=str.split("-"); 
    let finalstr:String=""; 
    finalstr=strarr[2]+"/"+strarr[1]+"/"+strarr[0]; 
    return finalstr; 
  }

  testfunction1(date:any):String{ 
    let str:String=date; 
    let strarr:String[]=str.split("-"); 
    let finalstr:String=""; 
    finalstr=strarr[2]+"-"+strarr[1]+"-"+strarr[0]; 
    return finalstr; 
  }
       
    }


  





