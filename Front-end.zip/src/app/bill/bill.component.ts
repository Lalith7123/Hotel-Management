import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Register } from './register';
import { RegisterserviceService } from './registerservice.service';

@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {

  register: Register=new Register("","","");
 
  public msg: String="Register form";
  registers:any;
constructor(private registerservice: RegisterserviceService,
  private route:Router) { }


  ngOnInit(): void {
  }

  public addregister(){
    let message: any;
    console.log(this.register);
     if(this.register.emailId=='' || this.register.password=='' || this.register.username=='' || this.register.confirm==''){
      alert("Enter all Details ");
     }else if(this.terms!=1){
           alert("Accept Terms and Conditions");
     }
     else if(this.validemail(this.register.emailId)==false){
     alert("Enter valid emailId");
    }
   else if(this.register.password==this.register.confirm){
        this.registerservice.addregister(this.register).subscribe((data)=>
       {message=data, alert(data);
      if(data=="Registered Successfully"){
        this.route.navigate(['/login']);
        }console.log(message);
      }
      
        );
    }else{
   alert( this.msg="Password Should be match");
    }
  }
validemail(email:any):any{
  let regex = new RegExp('[a-z0-9]+@[a-z]+\.[a-z]{2,3}');
 return regex.test(email);
  
}
test:any=1;
terms:any=null;
termsandconditions(){
  if(this.test==1){
        this.terms=1;
        this.test=2;
  }else{
    this.test=1;
    this.terms=null;
  }
}
}