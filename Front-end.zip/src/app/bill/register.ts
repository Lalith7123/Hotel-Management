export class Register{
    username?:String;
    emailId?:String;
    password?:String;
    confirm?:String;
    constructor(

    username?:String,
    emailId?:String,
    password?:String,
    confirm?:String

    ){this.username=username;
        this.emailId=emailId;
        this.password=password;
        this.confirm=confirm;}
}