import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Register } from '../bill/register';


@Injectable({
  providedIn: 'root'
})
export class RegisterserviceService {
  register: Register=new Register();
  baseurl="http://localhost:8084/Registration/register";
  constructor(private http:HttpClient) { }
message:any;

  public addregister(register: Register){
    return this.http.post(this.baseurl,register,{responseType:'text'});
  }
  

 

}
