export class Reservationdetails{
    id?:Number;
    membercode?:Number;
    status?:String;
    no_children?:Number;
    no_adults?:Number;
    check_in?:String;
    check_out?:String;
    no_nights?:Number;
    constructor(id?:Number,membercode?:Number,status?:String,no_children?:Number,no_adults?:Number,check_in?:String,check_out?:String,no_nights?:Number){
        this.id=id;
        this.membercode=membercode;
        this.status=status;
        this.no_children=no_children;
        this.no_adults=no_adults;
        this.check_in=check_in;
        this.check_out=check_out;
        this.no_nights=no_nights;
    }
  
}