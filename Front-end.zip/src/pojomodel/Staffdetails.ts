export class Staffdetails{
    staffcode?:Number;
    name?:String;
    address?:String;
    email?:String;
    salary?:Number;
    occupation?:String;
    salarystatus?:String;

    constructor(staffcode?:Number,name?:String,address?:String,email?:String,salary?:Number,
        occupation?:String,salarystatus?:String){
            this.staffcode=staffcode;
            this.name=name;
            this.address=address;
            this.email=email;
            this.salary=salary;
            this.occupation=occupation;
            this.salarystatus=salarystatus;
        }
}