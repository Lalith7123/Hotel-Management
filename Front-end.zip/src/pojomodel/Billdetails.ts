

export class Billdetails{

    billno?:Number;
    room_no?:Number;
     id?:Number;
    membercode?:Number;
    total?:Number;
    tax?:Number;
    GST?:Number;
    totalAmount?:Number;
    paytime?:String;
    card_details?:String;
    payment_status?:String;

    constructor(billno?:Number,room_no?:Number,id?:Number,membercode?:Number,total?:Number,tax?:Number,
        GST?:Number,totalAmount?:Number,paytime?:String,card_details?:String,payment_status?:String){
            this.billno=billno;
            this.room_no=room_no;
            this.id=id;
            this.membercode=membercode;
            this.total=total;
            this.tax=tax;
            this.GST=GST;
            this.totalAmount=totalAmount;
            this.paytime=paytime;
            this.card_details=card_details;
            this.payment_status=payment_status;
    }
}

