export class Guestdetails{
    membercode?:Number;
    resId?:Number;
    room_no?:Number;
    payment?:String;
    food_bill?:Number;
    name?:String;
    email?:String;
    company?:String;
    mobileno?:Number;
    gender?:String;
    address?:String;

    constructor(membercode?:Number,resId?:Number,room_no?:Number,payment?:String,food_bill?:Number,name?:String,email?:String,company?:String,mobileno?:Number,gender?:String,address?:String){
        this.membercode=membercode;
        this.resId=resId;
        this.room_no=room_no;
        this.payment=payment;
        this.food_bill=food_bill;
        this.name=name;
        this.email=email;
        this.company=company;
        this.mobileno=mobileno;
        this.gender=gender;
        this.address=address;
    }
}