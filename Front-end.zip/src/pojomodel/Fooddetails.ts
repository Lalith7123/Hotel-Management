export class Fooddetails{
    dish_id?:Number;
    dishname?:String;
    rate?:Number;
    
   

    constructor(dishname?:String,rate?:Number,dish_id?:Number){
        this.dishname=dishname;
        this.rate=rate;
        this.dish_id=dish_id;
    }
}
 